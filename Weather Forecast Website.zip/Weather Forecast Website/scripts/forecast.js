//              forecast.js is for interacting with api's 

const apikey='tifdzG7OW7gTIYoHWQSbx4mjTakKMc23';
//const citykey='260622';

//  get weather info        // after accuiring the KEY from getCity() function we use that KEY as ID as parameter here

const getWeather=async (id) => {        // STEP 2
const base='http://dataservice.accuweather.com/currentconditions/v1/';
const query=`${id}?apikey=${apikey}`;
const response=await fetch(base + query);
const data=await response.json();
//console.log(data);
return data[0];
};

//  get city info         // we first need this function to get city info AND a KEY which we need for weather info
const getCity=async (city)=>{       //      STEP 1

const base='http://dataservice.accuweather.com/locations/v1/cities/search';
const query=`?apikey=${apikey}&q=${city}`;

const response=await fetch(base + query);
const data=await response.json();

//console.log(data);
return data[0];
};


/*
getCity('lahore').then(data=>{
    return getWeather(data.Key);
}).then(data => { console.log(data);
}).catch(e=>{ console.log(e);
}); 
*/
//getWeather("260622");