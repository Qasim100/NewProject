//                      app.js is for DOM manipulation

const formlocation=document.querySelector('form');
const card=document.querySelector('.card');
const details=document.querySelector('.details');

const updateUI=(data)=>{
/*const cityDets=data.cityDets;
const weather=data.weather;
*/
//      Destructuring properties
const {cityDets, weather} = data;       // this works the same as line 8 and 9
        // updating details template
    details.innerHTML=`
    <h5 class="my-5">${cityDets.EnglishName}</h5>
          <div class="my-3">${weather.WeatherText}</div>
          <div class="display-4 my-4">
            <span>${weather.Temperature.Metric.Value}</span>
            <span>&deg;C</span>
            </div>
    `;
//          removing d-none from card class
if(card.classList.contains('d-none'))
{
    card.classList.remove('d-none');
}
};

const updateCity= async (ciety)=>{
//console.log(city);
const cityDets=await getCity(ciety);
const weather=await  getWeather(cityDets.Key);
 return{
     cityDets,
     weather
 };
};

// get city name or value and use it in updateCity() function
formlocation.addEventListener('submit',e =>{
e.preventDefault();
//      get city value
const ciity=formlocation.city.value.trim();
formlocation.reset();
//      update the ui with new city
/*                      //              use this method when you want to check data etc on console
updateCity(ciity)
.then(data=> console.log(data))
.catch(err=> console.log(err));
});
*/
updateCity(ciity)
.then(data=> updateUI(data))
.catch(err=> console.log(err));
});